# Employee Management (React + Redux Toolkit)
`npm install && npm run dev` · tests: `npm test`
- Smart: `EmployeePage` (state, dispatch). Dumb: `SearchBar`, `EmployeeTable`, `EmployeeForm`, `ConfirmDialog`.
- State: Redux Toolkit (createAsyncThunk + createEntityAdapter) with loading/error states for employees & countries.
- UI: Bootstrap 5. Mock API: mockapi.io endpoints from the assignment.
